# btools
R tools written by Noah Blair for use in data analysis.
